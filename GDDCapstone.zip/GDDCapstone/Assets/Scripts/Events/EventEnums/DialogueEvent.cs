public enum DialogueEvent
{
    Instruction,
    InstructionTrigger,
    Conversation,
    Key
}

public enum DialogueEventInfo
{
    None
}
