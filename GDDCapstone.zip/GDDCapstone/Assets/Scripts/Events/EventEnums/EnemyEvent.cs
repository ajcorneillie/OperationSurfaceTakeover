public enum EnemyEvent
{
    PlayerCollision,
    AbilityPlayerCollision,
    OnKill,
    OnEliteKill
}
public enum EnemyEventData
{
    Damage,
    Position,
    ExperienceAmount,
    Tier
}