public enum PlayerEvent
{
    StructurePurchase
}

public enum PlayerEventData
{
    Structure
    
}