using UnityEngine;

public static class PlayerStats
{
    public static int money = 0;
}
