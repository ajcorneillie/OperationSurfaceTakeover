using UnityEngine;

public enum TurretButtonEnum
{
    Turret,
    MachineGunTurret,
    FlameThrower,
    None,

}
