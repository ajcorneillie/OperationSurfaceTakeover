using UnityEngine;

public enum UnitButtonEnum
{
    Miner,
    None,
}
