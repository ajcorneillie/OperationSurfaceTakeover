using UnityEngine;

public enum WallButtonEnum
{
    BaseWall,
    None,
}
