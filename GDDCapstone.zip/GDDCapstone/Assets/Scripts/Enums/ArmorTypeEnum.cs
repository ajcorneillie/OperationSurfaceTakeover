using UnityEngine;

public enum ArmorTypeEnum
{
    LightArmor,
    HeavyArmor,
    Flying,
    FlyingHeavyArmor,
    InvincibleArmor,
    None,
}
